var input = new inputHandeler();
var snake = new Snake();
var food = new Food();
var wall = new Walls();
var enemy = new Enemy();

// function Grid()
// {
//     this.w = WIDTH;
//     this.h = HEIGHT;
//     this._grid = [];
//
//     this.addGrids = function() {
//         for(var i = 0; i < this.h / 10; i++) {
//             for(var j = 0; j < this.w / 10; j++) {
//                 this._grid.push({x: j * 10, y: i * 10});
//                 console.log("X: " + j * 10 + ", Y: " + i * 10);
//             }
//         }
//     }
// }

function Snake()
{
    this.x;
    this.y;
    this.width;
    this.height;
    this.total;
    this.tail;
    s_speed = 10;

    this.draw = function() {
        ctx.fillStyle = "lightgreen";
        for(var i = 0; i < this.tail.length; i++) {
            ctx.fillRect(this.tail[i].x, this.tail[i].y, this.width, this.height);
        }
    }

    this.update = function() {
        if (this.total === this.tail.length) {
            for (var i = 0; i < this.tail.length - 1; i++) {
              this.tail[i] = this.tail[i + 1];
            }
        }
        this.tail[this.total - 1] = {x: this.x, y: this.y};

        if(changeKey(S, DOWN_ARROW, 'UP')) key = 'DOWN';
        if(changeKey(W, UP_ARROW, 'DOWN')) key = 'UP';
        if(changeKey(D, RIGHT_ARROW, 'LEFT')) key = 'RIGHT';
        if(changeKey(A, LEFT_ARROW, 'RIGHT')) key = 'LEFT';

        switch (key) {
            case 'UP':
                snake.y -= s_speed;
                break;

            case 'DOWN':
                snake.y += s_speed;
                break;

            case 'RIGHT':
                snake.x += s_speed;
                break;

            case 'LEFT':
                snake.x -= s_speed;
                break;
        }
    }

    this.death = function() {
        if(AABB(enemy.x, enemy.y, enemy.width, enemy.height, this.x, this.y, this.width, this.height)) {
            GameOver();
        }

        for (var i = 0; i < this.tail.length; i++) {
            var pos = this.tail[i];
            var d = Math.dist(pos.x, pos.y, this.x, this.y);
            if(d < 1 && key != '') {
                GameOver();
            }
        }
    }
}

function Food()
{
    this.x = Math.floor(Math.random() * WIDTH / scale) * scale;
    this.y = Math.floor(Math.random() * HEIGHT / scale) * scale;
    this.width = scale;
    this.height = scale;

    this.draw = function() {
        ctx.fillStyle = "red";
        ctx.fillRect(this.x, this.y, this.width, this.height);
    }

    this.update = function() {
        this.x = Math.floor(Math.random() * WIDTH / scale) * scale;
        this.y = Math.floor(Math.random() * HEIGHT / scale) * scale;
    }

    this.eat = function() {
        if(AABB(this.x, this.y, this.width, this.height, snake.x, snake.y, snake.width, snake.height)) {
            eat_sound.play();
            time = 8;

            snake.total++;
            score++;
            this.update();

            return true;
        } else {
            return false;
        }
    }
}

function Enemy()
{
    this.x;
    this.y;
    this.width = this.height = scale;

    this.draw = function() {
        ctx.fillStyle = "black";
        ctx.fillRect(this.x, this.y, this.width, this.height);
    }

    this.update = function() {
        var diffX = snake.x - this.x;
	    var diffY = snake.y - this.y;

	    if(diffX > 0) { this.x += 5; }
	    else {
	        this.x -= 5;
	    }

	    if(diffY > 0) { this.y += 5; }
	    else {
	        this.y -= 5;
	    }
    }

    this.random = function() {
        this.x = Math.floor(Math.random() * WIDTH / scale) * scale;
        this.y = Math.floor(Math.random() * HEIGHT / scale) * scale;
    }
}

function Walls(wall)
{
    this.update = function() {
        if(walls == 1) {
            $('canvas').css({"border":"1px solid red"});
            if(snake.x < 0 || snake.x > WIDTH || snake.y < 0 || snake.y > HEIGHT) {
                GameOver();
            }
        } else {
            if(snake.x < 0) snake.x = WIDTH;
            if(snake.x > WIDTH) snake.x = 0;
            if(snake.y < 0) snake.y = HEIGHT;
            if(snake.y > HEIGHT) snake.y = 0;
        }
    }
}

function inputHandeler() {
    this.down = {};
    this.pressed = {};

    var _this = this;
    document.addEventListener("keydown", function (evt) {
        _this.down[evt.keyCode] = true;
    });
    document.addEventListener("keyup", function (evt) {
        delete _this.down[evt.keyCode];
        delete _this.pressed[evt.keyCode];
    });
};

inputHandeler.prototype.isDown = function(code) {
    return this.down[code];
};

inputHandeler.prototype.isPressed = function(code) {
    if(this.pressed[code]) {
                return false;
    } else if(this.down[code]) {
        return this.pressed[code] = true;
    }
    return false;
};

function DrawScore() {
    ctx.beginPath();

    ctx.fillStyle = "#fff";
    ctx.font = "25px VT323";
    ctx.fillText(score, WIDTH * 0.5, 30);

    ctx.stroke();
}

function AABB(ax, ay, aw, ah, bx, by, bw, bh) {
    return ax < bw + bx && ay < bh + by && bx < ax + aw && by < ay + ah;
}

Math.dist=function(x1,y1,x2,y2){
    if(!x2) x2=0;
    if(!y2) y2=0;
    return Math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
}

function GameOver() {
    snake.total = 1;
    key = '';
    snake.x = snake.y = scale;

    document.getElementById('score_text').innerHTML = score;

    score = 0;

    init();

    gv = true;

    $('canvas').remove();
    $('.all_snake').css({"display":"block"});
    $('#menu').css({"display":"none"});
    $('#setting').css({"display":"none"});
    $('#gameover').css({"display":"block"});
    $('#note').css({"display":"none"});

    food.update();
    enemy.random();
}

function settings()
{
    $('canvas').remove();
    $('.all_snake').css({"display":"block"});
    $('#menu').css({"display":"none"});
    $('#gameover').css({"display":"none"});
    $('#setting').css({"display":"block"});
    $('#note').css({"display":"none"});
}

function note()
{
    alert("Controller: 'W A S D' or 'Key Arrows'\nPress 'P' to pause the game\n\n!!Note: In game is timer. If timer ends, you lose. Beware of black snake, he is small, but very toxic...");
}

function Pause()
{
    alert("Paused");
}

function Timer()
{
    time = time1;
    timer = setInterval(function() {
        if(gv == false) {
            time--;
        }
        if(time < 0) { GameOver(); }
    }, 1000);
}


function changeKey(key1, key2, key3) {
    return key != key3 && snake.x >= 0 && snake.x <= WIDTH && snake.y >= 0 && snake.y <= HEIGHT && gv == false && (input.isPressed(key1) || input.isPressed(key2));
}
