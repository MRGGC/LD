function init()
{
    speed = $('input[name="speed"]:checked').val();
    walls = $('input[name="wall"]:checked').val();
    sound = $('input[name="music"]:checked').val();
    time = $('input[name="difficulty"]:checked').val();
    enem = $('input[name="enemy"]:checked').val();
    time = parseInt(time);

    time1 = time;

    if(enem == '1') {
        enemy.x = Math.floor(Math.random() * WIDTH / scale) * scale;
        enemy.y = Math.floor(Math.random() * HEIGHT / scale) * scale;
    }

    clearInterval(run);
    clearInterval(timer);

    gv = false;


    $('#setting').css({"display":"none"});
    $('#gameover').css({"display":"none"});
    $('#menu').css({"display":"none"});


    snake.x = snake.y = scale;
    snake.width = snake.height = scale - 1;
    snake.total = 2;
    snake.tail = [];

    canvas = document.createElement("canvas");
    canvas.width = WIDTH;
    canvas.height = HEIGHT;
    ctx = canvas.getContext("2d");
    document.body.appendChild(canvas);

    run = setInterval(function() {
    if(gv == false) {
        ctx.clearRect(0, 0, WIDTH, HEIGHT);

        snake.update();
        snake.death();
        snake.draw();

        if(enem == '1' && gv == false) {
            enemy.update();
            enemy.draw();
        }

        food.eat();
        food.draw();

        wall.update(walls);

        DrawScore();


        if(input.isPressed(P)) {
            Pause();
        }


        if(time <= 3) {
            ctx.beginPath();
            ctx.fillStyle = "red";
            ctx.font = "100px";
            ctx.fillText(time, WIDTH / 2, (HEIGHT - 60) / 2);
            ctx.stroke();
        }

    }

    if(gv === true && input.isPressed(32)) {
        init();
    }
    }, speed);

    switch (sound) {
        case '1':
            bg_sound.play();
            bg_sound.loop = true;
            break;
        case '0':
            bg_sound.pause();
            bg_sound.loop = false;
            break;

    }

    Timer();
}





















//init();
