var canvas, ctx;
var key = '';
var gv = false;
var scale = 10;
var time, time1, timer;
var W = 87, S = 83, D = 68, A = 65, P = 80;
var UP_ARROW = 38, DOWN_ARROW = 40, RIGHT_ARROW = 39, LEFT_ARROW = 37;

var bg_sound = new Audio();
bg_sound.src = './sounds/sound.mp3';
var eat_sound = new Audio();
eat_sound.src = './sounds/eat.mp3';

var score = 0;
var run;

//settings vars
var speed, walls, sound, enem;

var HEIGHT = 400, WIDTH = 520;
